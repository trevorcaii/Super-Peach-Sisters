#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include "Level.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    ~StudentWorld();
    bool overlap(int x, int y, Actor* actor1, Actor*& actor2);
    void add(Actor*);
    virtual int init();
    virtual int move();
    virtual void cleanUp();
private:
    std::vector<Actor*> m_objects;
    Peach* peach;
};

#endif // STUDENTWORLD_H_
