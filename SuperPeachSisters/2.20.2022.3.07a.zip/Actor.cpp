#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size) :GraphObject(imageID, initialX, initialY, initialDirection, depth, size)
{
    m_w = w;
    m_aliveStatus = true;
}

bool Actor::isAlive()
{
    return m_aliveStatus;
}

void Actor::setDead()
{
    m_aliveStatus = false;
}

StudentWorld* Actor::getWorld()
{
    return m_w;
}

bool Actor::getBlocking()
{
    return false;
}

bool Actor::getBonkable()
{
    return true;
}

void Actor::bonk(Actor* bonker)
{
}

void Actor::doSomething()
{
}

Obstacle::Obstacle(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size)
    :Actor(w, imageID, initialX, initialY, initialDirection, depth, size)
{
}

bool Obstacle::getBlocking()
{
    return true;
}

Block::Block(StudentWorld* w, int initialX, int initialY, int contains)
    :Obstacle(w, IID_BLOCK, initialX, initialY, 0, 2, 1.0)
{
    m_containsGoodie = contains;
}

void Block::bonk(Actor* bonker)
{
    switch (m_containsGoodie) {
        case 0:
            getWorld()->playSound(SOUND_PLAYER_BONK);
            break;
        case 1:
        {
            Actor* n = new Star(getWorld(), getX(), getY()+8);
            getWorld()->add(n);
            getWorld()->playSound(SOUND_POWERUP_APPEARS);
            m_containsGoodie = 0;
            break;
        }
        case 2:
        {
            Actor* n = new Flower(getWorld(), getX(), getY()+8);
            getWorld()->add(n);
            getWorld()->playSound(SOUND_POWERUP_APPEARS);
            m_containsGoodie = 0;
            break;
        }
        case 3:
        {
            Actor* n = new Mushroom(getWorld(), getX(), getY()+8);
            getWorld()->add(n);
            getWorld()->playSound(SOUND_POWERUP_APPEARS);
            m_containsGoodie = 0;
            break;
        }
        default:
            break;
    }
}

Pipe::Pipe(StudentWorld* w, int initialX, int initialY)
:Obstacle(w, IID_PIPE, initialX, initialY, 0, 2, 1.0)
{
}

PointAdders::PointAdders(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth)
:Actor(w, imageID, initialX, initialY, initialDirection, depth, size)
{
    m_pointsWorth = pointsWorth;
}

int PointAdders::getPoints()
{
    return m_pointsWorth;
}

Goodies::Goodies(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth)
:PointAdders(w, imageID, initialX, initialY, initialDirection, depth, size, pointsWorth)
{
}

void Goodies::doSomething()
{
    Actor* collision;
    if(!getWorld()->overlap(getX(), getY()-2, this, collision) || (getWorld()->overlap(getX(), getY()-2, this, collision) && !collision->getBlocking()))
    {
        moveTo(getX(), getY()-2);
    }
    if(getDirection() == 180)
    {
        if(!getWorld()->overlap(getX()-2, getY(), this, collision) || (getWorld()->overlap(getX()-2, getY(), this, collision) && !collision->getBlocking()))
        {
            setDirection(180);
            moveTo(getX()-2, getY());
        }
        else
            setDirection(0);
    }
    if(getDirection() == 0)
    {
        if(!getWorld()->overlap(getX()+2, getY(), this, collision) || (getWorld()->overlap(getX()+2, getY(), this, collision) && !collision->getBlocking()))
        {
            setDirection(0);
            moveTo(getX()+2, getY());
        }
        else
            setDirection(180);
    }
    if(getWorld()->overlap(getX(), getY(), this, collision))
    {
        if(typeid(*collision) == typeid(Peach))
        {
            collision->bonk(this);
            getWorld()->playSound(SOUND_PLAYER_POWERUP);
            setDead();
        }
    }
}

Flower::Flower(StudentWorld* w, int initialX, int initialY)
:Goodies(w, IID_FLOWER, initialX, initialY, 0, 1, 1.0, 50)
{
    
}

Mushroom::Mushroom(StudentWorld* w, int initialX, int initialY)
:Goodies(w, IID_MUSHROOM, initialX, initialY, 0, 1, 1.0, 75)
{
}

Star::Star(StudentWorld* w, int initialX, int initialY)
:Goodies(w, IID_STAR, initialX, initialY, 0, 1, 1.0, 100)
{
}

Peach::Peach(StudentWorld* w, int initialX, int initialY)
:Actor(w, IID_PEACH, initialX, initialY, 0, 0, 1.0)
{
    m_Hp = 1;
    m_remaining_jump_distance = 0;
    m_shootPowerStatus = false;
    m_jumpPowerStats = false;
    m_starTimer = 0;
}

void Peach::doSomething()
{
    int ui;
    Actor* collision;
    
    if(m_remaining_jump_distance > 0)
    {
        if(getWorld()->overlap(getX(), getY()+4, this, collision))
        {
            collision->bonk(this);
            m_remaining_jump_distance = 0;
        }
        else
        {
            moveTo(getX(), getY()+4);
            m_remaining_jump_distance--;
        }
    }
    else
    {
        if(!getWorld()->overlap(getX(), getY()-4, this, collision))
            moveTo(getX(), getY()-4);
    }
    
    if(getWorld()->getKey(ui))
    {
        switch (ui) {
            case KEY_PRESS_LEFT:
            {
                if(!getWorld()->overlap(getX()-4, getY(), this, collision) || (getWorld()->overlap(getX()-4, getY(), this, collision) && !collision->getBlocking()))
                {
                    setDirection(180);
                    moveTo(getX()-4, getY());
                }
                break;
            }
            case KEY_PRESS_RIGHT:
            {
                if(!getWorld()->overlap(getX()+4, getY(), this, collision) || (getWorld()->overlap(getX()+4, getY(), this, collision) && !collision->getBlocking()))
                {
                    setDirection(0);
                    moveTo(getX()+4, getY());
                }
                break;
            }
            case KEY_PRESS_UP:
            {
                if(getWorld()->overlap(getX(), getY()-1, this, collision))
                {
                    if(m_jumpPowerStats)
                        m_remaining_jump_distance = 12;
                    else
                        m_remaining_jump_distance = 8;
                    getWorld()->playSound(SOUND_PLAYER_JUMP);
                }
                break;
            }
            default:
                break;
        }
    }
    return;
}

void Peach::bonk(Actor* bonker)
{
    if(typeid(*bonker) == typeid(Mushroom))
    {
        m_jumpPowerStats = true;
        m_Hp = 2;
    }
    if(typeid(*bonker) == typeid(Flower))
    {
        m_shootPowerStatus = true;
        m_Hp = 2;
    }
    if(typeid(*bonker) == typeid(Star))
        m_starTimer = 150;
}
