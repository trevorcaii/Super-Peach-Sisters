#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <typeinfo>
class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor: public GraphObject
{
public:
    Actor(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size);
    bool isAlive();
    void setDead();
    StudentWorld* getWorld();
    virtual bool getBlocking();
    virtual bool getBonkable();
    virtual void bonk(Actor* bonker);
    virtual void doSomething();
private:
    StudentWorld* m_w;
    bool m_aliveStatus;
};

class Obstacle: public Actor
{
public:
    Obstacle(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size);
    bool getBlocking();
};

class Block: public Obstacle
{
public:
    Block(StudentWorld* w, int initialX, int initialY, int contains);
    void bonk(Actor* bonker);
private:
    int m_containsGoodie;
};

class Pipe: public Obstacle
{
public:
    Pipe(StudentWorld* w, int initialX, int initialY);
};

class PointAdders: public Actor
{
public:
    PointAdders(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth);
    int getPoints();
private:
    int m_pointsWorth;
};

class Goodies: public PointAdders
{
public:
    Goodies(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth);
    void doSomething();
};

class Flower: public Goodies
{
public:
    Flower(StudentWorld* w, int initialX, int initialY);
};

class Mushroom: public Goodies
{
public:
    Mushroom(StudentWorld* w, int initialX, int initialY);
};

class Star: public Goodies
{
public:
    Star(StudentWorld* w, int initialX, int initialY);
};

class Peach: public Actor
{
public:
    Peach(StudentWorld* w, int initialX, int initialY);
    void doSomething();
    void bonk(Actor* bonker);
private:
    int m_Hp;
    int m_remaining_jump_distance;
    bool m_shootPowerStatus;
    bool m_jumpPowerStats;
    int m_starTimer;
};



#endif // ACTOR_H_
