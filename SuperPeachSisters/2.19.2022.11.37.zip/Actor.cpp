#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size) :GraphObject(imageID, initialX, initialY, initialDirection, depth, size)
{
    m_w = w;
    m_aliveStatus = true;
}

bool Actor::isAlive()
{
    return m_aliveStatus;
}

void Actor::setAlive(bool condition)
{
    m_aliveStatus = condition;
}

StudentWorld* Actor::getWorld()
{
    return m_w;
}

bool Actor::getBlocking()
{
    return false;
}

bool Actor::getBonkable()
{
    return true;
}

void Actor::bonk()
{
    return;
}

void Actor::doSomething()
{
    return;
}

Obstacle::Obstacle(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size)
    :Actor(w, imageID, initialX, initialY, initialDirection, depth, size)
{
}

bool Obstacle::getBlocking()
{
    return true;
}

Block::Block(StudentWorld* w, int initialX, int initialY)
:Obstacle(w, IID_BLOCK, initialX, initialY, 0, 2, 1.0)
{
    m_containsGoodie = true;
}

void Block::bonk()
{
    return;
}

Pipe::Pipe(StudentWorld* w, int initialX, int initialY)
:Obstacle(w, IID_PIPE, initialX, initialY, 0, 2, 1.0)
{
}

Peach::Peach(StudentWorld* w, int initialX, int initialY)
:Actor(w, IID_PEACH, initialX, initialY, 0, 0, 1.0)
{
    m_Hp = 1;
    m_remaining_jump_distance = 0;
}

void Peach::doSomething()
{
    int ui;
    Actor* collision;
    if(getWorld()->getKey(ui))
    {
        switch (ui) {
            case KEY_PRESS_LEFT:
            {
                if(!getWorld()->overlap(getX()-4, getY(), this, collision) || (getWorld()->overlap(getX()-4, getY(), this, collision) && !collision->getBlocking()))
                {
                    setDirection(180);
                    moveTo(getX()-4, getY());
                }
                break;
            }
            case KEY_PRESS_RIGHT:
            {
                if(!getWorld()->overlap(getX()+4, getY(), this, collision) || (getWorld()->overlap(getX()-4, getY(), this, collision) && !collision->getBlocking()))
                {
                    setDirection(0);
                    moveTo(getX()+4, getY());
                }
                break;
            }
            default:
                break;
        }
    }
    return;
}

void Peach::bonk()
{
    return;
}
