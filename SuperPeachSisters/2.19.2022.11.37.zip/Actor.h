#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
//#include "StudentWorld.h"
class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor: public GraphObject
{
public:
    Actor(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size);
    bool isAlive();
    void setAlive(bool condition);
    StudentWorld* getWorld();
    virtual bool getBlocking();
    virtual bool getBonkable();
    virtual void bonk();
    virtual void doSomething();
private:
    StudentWorld* m_w;
    bool m_aliveStatus;
};

class Obstacle: public Actor
{
public:
    Obstacle(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size);
    bool getBlocking();
};

class Block: public Obstacle
{
public:
    Block(StudentWorld* w, int initialX, int initialY);
    void bonk();
//    void doSomething();
private:
    bool m_containsGoodie;
};

class Pipe: public Obstacle
{
public:
    Pipe(StudentWorld* w, int initialX, int initialY);
};

class Peach: public Actor
{
public:
    Peach(StudentWorld* w, int initialX, int initialY);
    void doSomething();
    void bonk();
private:
    int m_Hp;
    int m_remaining_jump_distance;
};



#endif // ACTOR_H_
