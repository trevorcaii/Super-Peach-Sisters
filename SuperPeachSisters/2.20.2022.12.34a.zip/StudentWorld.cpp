#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

bool StudentWorld::overlap(int x, int y, Actor* actor1, Actor*& actor2)
{
    for(auto& element : m_objects)
        if(element != actor1)
            if(((x >= element->getX() && x <= element->getX()+SPRITE_WIDTH-1) || (x+SPRITE_WIDTH-1 >= element->getX() && x+SPRITE_WIDTH-1 <= element->getX()+SPRITE_WIDTH-1)) && ((y >= element->getY() && y <= element->getY()+SPRITE_HEIGHT-1) || (y+SPRITE_HEIGHT-1 >= element->getY() && y+SPRITE_HEIGHT-1 <= element->getY()+SPRITE_HEIGHT-1)))
            {
                actor2 = element;
                return true;
            }
    return false;
}

void StudentWorld::add(Actor* adder)
{
    m_objects.push_back(adder);
}

int StudentWorld::init()
{
    Level lev(assetPath());
    string level_file = "level01.txt";
    Level::LoadResult result = lev.loadLevel(level_file);
    if(result == Level::load_fail_file_not_found || result == Level::load_fail_bad_format)
        cerr << "bad file" << endl;
    else if(result == Level::load_success)
    {
        Level::GridEntry ge;
        for(int lx = 0; lx < GRID_WIDTH; lx++)
            for(int ly = 0; ly < GRID_HEIGHT; ly++)
            {
                ge = lev.getContentsOf(lx, ly);
                switch(ge)
                {
                    case Level::empty:
                        break;
                    case Level::block:
                        m_objects.push_back(new Block(this, lx*SPRITE_WIDTH, ly*SPRITE_HEIGHT, 0));
                        break;
                    case Level::star_goodie_block:
                        m_objects.push_back(new Block(this, lx*SPRITE_WIDTH, ly*SPRITE_HEIGHT, 1));
                        break;
                    case Level::flower_goodie_block:
                        m_objects.push_back(new Block(this, lx*SPRITE_WIDTH, ly*SPRITE_HEIGHT, 2));
                        break;
                    case Level::mushroom_goodie_block:
                    {
                        m_objects.push_back(new Block(this, lx*SPRITE_WIDTH, ly*SPRITE_HEIGHT, 3));
                        break;
                    }
                    case Level::pipe:
                        m_objects.push_back(new Pipe(this, lx*SPRITE_WIDTH, ly*SPRITE_HEIGHT));
                        break;
                    case Level::peach:
                        m_objects.push_back(new Peach(this, lx*SPRITE_WIDTH, ly*SPRITE_HEIGHT));
                        break;
                    default:
                        break;
                }
            }
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    for(auto& element : m_objects)
        element->doSomething();
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    m_objects.clear();
}

