#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size) :GraphObject(imageID, initialX, initialY, initialDirection, depth, size)
{
    m_w = w;
    m_aliveStatus = true;
}

bool Actor::isAlive()
{
    return m_aliveStatus;
}

void Actor::setAlive(bool condition)
{
    m_aliveStatus = condition;
}

StudentWorld* Actor::getWorld()
{
    return m_w;
}

bool Actor::getBlocking()
{
    return false;
}

bool Actor::getBonkable()
{
    return true;
}

void Actor::bonk()
{
    return;
}

void Actor::doSomething()
{
    return;
}

Obstacle::Obstacle(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size)
    :Actor(w, imageID, initialX, initialY, initialDirection, depth, size)
{
}

bool Obstacle::getBlocking()
{
    return true;
}

Block::Block(StudentWorld* w, int initialX, int initialY, int contains)
:Obstacle(w, IID_BLOCK, initialX, initialY, 0, 2, 1.0)
{
    m_containsGoodie = contains;
}

void Block::bonk()
{
    switch (m_containsGoodie) {
        case 0:
            getWorld()->playSound(SOUND_PLAYER_BONK);
            break;
        case 1:
        {
            getWorld()->playSound(SOUND_POWERUP_APPEARS);
            m_containsGoodie = 0;
            break;
        }
        case 2:
        {
            getWorld()->playSound(SOUND_POWERUP_APPEARS);
            m_containsGoodie = 0;
            break;
        }
        case 3:
        {
            Actor* n = new Mushroom(getWorld(), getX(), getY()+8);
            getWorld()->add(n);
            getWorld()->playSound(SOUND_POWERUP_APPEARS);
            m_containsGoodie = 0;
            break;
        }
        default:
            break;
    }
}

Pipe::Pipe(StudentWorld* w, int initialX, int initialY)
:Obstacle(w, IID_PIPE, initialX, initialY, 0, 2, 1.0)
{
}

Peach::Peach(StudentWorld* w, int initialX, int initialY)
:Actor(w, IID_PEACH, initialX, initialY, 0, 0, 1.0)
{
    m_Hp = 1;
    m_remaining_jump_distance = 0;
}

PointerAdders::PointerAdders(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth)
    :Actor(w, imageID, initialX, initialY, initialDirection, depth, size)
{
    m_pointsWorth = pointsWorth;
}

int PointerAdders::getPoints()
{
    return m_pointsWorth;
}

Mushroom::Mushroom(StudentWorld* w, int initialX, int initialY)
    :PointerAdders(w, IID_MUSHROOM, initialX, initialY, 0, 1, 1.0, 75)
{
}

void Peach::doSomething()
{
    int ui;
    Actor* collision;
    
    if(m_remaining_jump_distance > 0)
    {
        if(getWorld()->overlap(getX(), getY()+4, this, collision))
        {
            collision->bonk();
            m_remaining_jump_distance = 0;
        }
        else
        {
            moveTo(getX(), getY()+4);
            m_remaining_jump_distance--;
        }
    }
    else
    {
        if(!getWorld()->overlap(getX(), getY()-4, this, collision))
            moveTo(getX(), getY()-4);
    }
    
    if(getWorld()->getKey(ui))
    {
        switch (ui) {
            case KEY_PRESS_LEFT:
            {
                if(!getWorld()->overlap(getX()-4, getY(), this, collision) || (getWorld()->overlap(getX()-4, getY(), this, collision) && !collision->getBlocking()))
                {
                    setDirection(180);
                    moveTo(getX()-4, getY());
                }
                break;
            }
            case KEY_PRESS_RIGHT:
            {
                if(!getWorld()->overlap(getX()+4, getY(), this, collision) || (getWorld()->overlap(getX()-4, getY(), this, collision) && !collision->getBlocking()))
                {
                    setDirection(0);
                    moveTo(getX()+4, getY());
                }
                break;
            }
            case KEY_PRESS_UP:
            {
                if(getWorld()->overlap(getX(), getY()-1, this, collision))
                {
                    m_remaining_jump_distance = 8;
                    getWorld()->playSound(SOUND_PLAYER_JUMP);
                }
                break;
            }
            default:
                break;
        }
    }
    return;
}

void Peach::bonk()
{
    return;
}
