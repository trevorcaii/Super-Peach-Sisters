#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <cstdlib>
#include <cmath>
class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor: public GraphObject
{
public:
    Actor(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size);
    bool isAlive();
    void setDead();
    StudentWorld* getWorld();
    virtual bool getBlocking();
    virtual bool getBonkable();
    virtual bool isDamageable();
    virtual void takeDamage();
    virtual void bonk(Actor* bonker);
    virtual void doSomething();
private:
    StudentWorld* m_w;
    bool m_aliveStatus;
};

class Obstacle: public Actor
{
public:
    Obstacle(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size);
    bool getBlocking();
};

class Block: public Obstacle
{
public:
    Block(StudentWorld* w, int initialX, int initialY, int contains);
    void bonk(Actor* bonker);
private:
    int m_containsGoodie;
};

class Pipe: public Obstacle
{
public:
    Pipe(StudentWorld* w, int initialX, int initialY);
};

class Peach: public Actor
{
public:
    Peach(StudentWorld* w, int initialX, int initialY);
    void doSomething();
    bool isDamageable();
    void takeDamage();
    bool shootPowerStatus();
    void updateShootPower(bool status);
    bool jumpPowerStatus();
    void updateJumpPower(bool status);
    bool starPowerStatus();
    void updateStarPower(int time);
    void bonk(Actor* bonker);
private:
    int m_Hp;
    int m_remaining_jump_distance;
    bool m_shootPowerStatus;
    bool m_jumpPowerStats;
    int m_starTimer;
    int m_tempInvincibility;
    int m_rechargeTime;
};


class PointAdders: public Actor
{
public:
    PointAdders(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth);
    int getPoints();
private:
    int m_pointsWorth;
};

class Goodies: public PointAdders
{
public:
    Goodies(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection, int depth, double size, int pointsWorth);
    virtual void powerUp();
    void doSomething();
};

class Flower: public Goodies
{
public:
    Flower(StudentWorld* w, int initialX, int initialY);
    void powerUp();
};

class Mushroom: public Goodies
{
public:
    Mushroom(StudentWorld* w, int initialX, int initialY);
    void powerUp();
};

class Star: public Goodies
{
public:
    Star(StudentWorld* w, int initialX, int initialY);
    void powerUp();
};

class Portals: public PointAdders
{
public:
    Portals(StudentWorld* w, int imageID, int initialX, int initialY);
    virtual int statusChanger();
    void doSomething();
};

class Flag: public Portals
{
public:
    Flag(StudentWorld* w, int initialX, int initialY);
};

class Mario: public Portals
{
public:
    Mario(StudentWorld* w, int initialX, int initialY);
    int statusChanger();
};

class Projectiles: public Actor
{
public:
    Projectiles(StudentWorld* w, int imageID, int initialX, int initialY, int initialDirection);
    virtual void damage();
    void doSomething();
};

class PeachFire: public Projectiles
{
public:
    PeachFire(StudentWorld* w, int initialX, int initialY, int initialDirection);
};

class Shell: public Projectiles
{
public:
    Shell(StudentWorld* w, int initialX, int initialY, int initialDirection);
};

class PiranhaFire: public Projectiles
{
public:
    PiranhaFire(StudentWorld* w, int initialX, int initialY, int initialDirection);
    void damage();
};

class Enemies: public PointAdders
{
public:
    Enemies(StudentWorld* w, int imageID, int initialX, int initialY);
    bool isDamageable();
    void bonk(Actor* bonker);
    virtual void takeDamage();
    virtual void doSomething();
};

class Goomba: public Enemies
{
public:
    Goomba(StudentWorld*w, int initialX, int initialY);
};

class Koopa: public Enemies
{
public:
    Koopa(StudentWorld*w, int initialX, int initialY);
    void takeDamage();
};

class Piranha: public Enemies
{
public:
    Piranha(StudentWorld*w, int initialX, int initialY);
    void doSomething();
private:
    int m_fireDelay;
};
#endif // ACTOR_H_
